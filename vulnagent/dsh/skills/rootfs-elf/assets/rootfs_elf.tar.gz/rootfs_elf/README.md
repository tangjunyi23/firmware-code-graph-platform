# rootfs_elf

离线 RootFS 批量 ELF 分析工具。

功能：
- RootFS 扫描与 ELF 识别
- 任务编排（resume/force/timeout/retry）
- `checksec` JSON 解析与索引生成
- 可选 IDA 单 ELF 导出（strings/imports/exports/data/decompile）
- 输出目录结构与 `summary.json`

直接运行：

```bash
cd /home/mowen/tools/ida/rootfs_elf
python cli.py /path/to/rootfs --progress
```

说明：
- CLI 默认会分析 `ET_EXEC` 和 `ET_DYN`
- 也就是说现代 PIE 可执行文件和 `.so` 默认都会进入扫描队列

如果要导出 IDA 结果：

```bash
cd /home/mowen/tools/ida/rootfs_elf
IDADIR=/path/to/ida python cli.py /path/to/rootfs --run-ida --workers 4 --progress
```

也可以在 `backend/conf/ndisec.conf` 中配置：

```ini
[ndisec]
ida_dir = /home/mowen/ida-pro-9.1
```

之后直接运行：

```bash
cd /home/mowen/tools/ida/rootfs_elf
python cli.py /path/to/rootfs --run-ida --workers 4 --progress
```

全局安装命令：

```bash
cd /home/mowen/tools/ida/rootfs_elf
python -m pip install --user -e .
```

安装后可在任意目录直接使用：

```bash
rootfs-elf /path/to/rootfs --run-ida --progress
```

常用参数：
- `-o, --out-dir` 指定输出目录
- `--include-so` 包含共享库 `ET_DYN`，当前 CLI 默认已开启
- `--exclude` 用正则排除路径
- `--max-bytes` 跳过过大的文件
- `--run-ida` 启用 IDA 导出
- `--skip-memory` 不导出内存段
- `--no-decompile-funcs` 不导出逐函数反编译
- `--no-function-index` 不导出函数索引

输出目录默认在当前模块下的 `output/`，如果外层 `mofuzz` 配置存在，则优先沿用原项目缓存目录。
